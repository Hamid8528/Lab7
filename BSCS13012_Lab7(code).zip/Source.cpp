#include<stdio.h>
#include<conio.h>
#include<iostream>
using namespace std;
class ATM
{
private:
	int Total_users;

public:
	void setUser()
	{
		static int a = 1;
		Total_users = a;
		a++;
	}
	int getUser()
	{
		return Total_users;
	}
	
};
class User
{
private:
	char *name;
	char *pass;
public:
	void setName(char *a)
	{
		this->name = a;
	//	strcpy_s(this->name,sizeof(this->name), a);
	}
	char getName()
	{
		return *(name);
	}
	void setPass(char *p)
	{
		this->pass = p;
		//strcpy_s(this->pass,sizeof(this->pass), p);
	}
	char getPass()
	{
		return *(pass);
	}

};
class AccountsMangament
{
private:
	int totalAmount;
//	int remainingAmount;
public:
	AccountsMangament()
	{
		this->totalAmount = 0;
	}
	void setTotalAmount(int a, AccountsMangament &m)
	{
		//m.totalAmount = 0;
		m.totalAmount += a;
	}
	int getTotalAmount(AccountsMangament &f)
	{
		return f.totalAmount;
	}
	void deductBalance(int m,AccountsMangament &a)
	{
		a.totalAmount =a.totalAmount - m;
	}

};
int main()
{
	ATM a; User u; AccountsMangament M;
	M.setTotalAmount(10000, M);
	int op;
	cout << "Welcom to ITU ATM\n";
	while (true)
	{
	cout << "please select an option\n";
	cout << "1) for creating account \n 2) For logging in \n 3) Quitting\n";
	cin >> op;
	if (op == 1)
	{
		cout << "please enter your name\n";
		char* n;char* p;
		n = new (char);

		cin >> n;
		u.setName(n);
		cout << "Please enter password\n";
		p = new (char);
		cin >> p;
		u.setPass(p);
		a.setUser();
		cout << "You have successfully created an account\n";
	}
	else if (op == 2)
	{
		while (true)
		{

			cout << "Please enter your user name\n";
			char *c;
			c = new(char);
			cin >> c;
			if (*(c) == u.getName())
			{
				
				while (true)
				{
					cout << "Please enter your password\n";
					char *a;
					a = new (char);
					cin >> a;
					if (*(a) == u.getPass())
					{
						cout << "you have successfully logged in\n";
						while (true)
						{
							cout << "\nPlease select an option\n";
							cout << "1) For checking your balance \n2) for deducting balance \n3) for adding balance \n4) return to the main menu";
							int option = 0;
							cin >> option;
							if (option == 1)
								cout << "Your current  balance is" << M.getTotalAmount(M);
							else if (option == 2)
							{
								int amount;
								cout << "Please enter how much amount you want to deduct";
								cin >> amount;
								M.deductBalance(amount,M);
								cout << "your remaining balance is" << M.getTotalAmount(M);

							}
							else if (option == 3)
							{
								int add;
								cout << "Enter how much you want to add";
								cin >> add;
								M.setTotalAmount(add,M);
							}
							else
								break;
						}
				


						break;
					}
					else
						cout << "Wrong password please try again\n";
				}
				break;
			}
			else
			{
				cout << "wrong username\n";
			}
		}
	}
	else
	{
		break;
	}
 }
}